from fastapi import FastAPI, Depends, HTTPException, status, Request, Response
from sqlalchemy.orm import Session
from typing import List
import time
import json
import models
import schemas
from database import get_db
from redis_db import get_redis

app = FastAPI(title="Trabalho de Redis - Professor Fabricio")

# --- FASE 04: Contador de Requisições e Rate Limiting ---
@app.middleware("http")
async def rate_limiter_middleware(request: Request, call_next):
    r = get_redis()
    client_ip = request.client.host
    key = f"rate_limit:{client_ip}"
    
    # Incrementa o contador global de requisições
    r.incr("total_requisicoes")
    
    # Rate Limiting: Máximo de 10 requisições por minuto por IP
    requests = r.incr(key)
    if requests == 1:
        r.expire(key, 60)
        
    if requests > 10:
        return Response(
            content="Rate limit excedido. Tente novamente em um minuto.", 
            status_code=429
        )
    
    response = await call_next(request)
    return response

# --- FASE 02: Cache com TTL ---
@app.get("/items-lento", response_model=List[schemas.TarefaResponse])
def get_items_cacheado(response: Response, db: Session = Depends(get_db)):
    r = get_redis()
    cache_key = "lista_tarefas_cache"
    
    # Tenta buscar no cache (Redis)
    cached_data = r.get(cache_key)
    
    if cached_data:
        response.headers["X-Cache"] = "HIT"
        return json.loads(cached_data)
    
    # Se não estiver no cache (MISS)
    response.headers["X-Cache"] = "MISS"
    
    # Simula uma operação lenta de banco de dados
    time.sleep(2)
    tarefas = db.query(models.Tarefa).all()
    
    # Converte para formato serializável e salva no Redis com TTL de 30s
    # Usamos uma lista de dicts para o JSON
    tarefas_dict = [
        {"id": t.id, "titulo": t.titulo, "descricao": t.descricao, "concluida": t.concluida} 
        for t in tarefas
    ]
    r.setex(cache_key, 30, json.dumps(tarefas_dict))
    
    return tarefas

# --- FASE 03: Fila (Produtor) ---
@app.post("/enviar-pedido", status_code=202)
def enviar_pedido(item: str):
    r = get_redis()
    pedido = {
        "id": int(time.time()),
        "item": item,
        "status": "pendente"
    }
    
    # LPUSH coloca o pedido no início da fila no Redis
    r.lpush("fila_pedidos", json.dumps(pedido))
    
    return {"message": "Pedido enviado para a fila", "pedido": pedido}

# --- CRUD ORIGINAL (Persistência no Postgres) ---
@app.get("/tarefas/", response_model=List[schemas.TarefaResponse])
def read_tarefas(db: Session = Depends(get_db)):
    return db.query(models.Tarefa).all()

@app.post("/tarefas/", response_model=schemas.TarefaResponse, status_code=201)
def create_tarefa(tarefa: schemas.TarefaCreate, db: Session = Depends(get_db)):
    db_tarefa = models.Tarefa(**tarefa.model_dump())
    db.add(db_tarefa)
    db.commit()
    db.refresh(db_tarefa)
    
    # Limpa o cache para que a próxima leitura pegue o dado novo
    r = get_redis()
    r.delete("lista_tarefas_cache")
    
    return db_tarefa

# Rota de estatísticas (Consolidando Fase 04)
@app.get("/status")
def get_status():
    r = get_redis()
    return {
        "total_requisicoes_api": r.get("total_requisicoes") or 0,
        "pedidos_na_fila": r.llen("fila_pedidos"),
        "info": "Use /items-lento para testar o cache e /enviar-pedido para testar a fila."
    }
