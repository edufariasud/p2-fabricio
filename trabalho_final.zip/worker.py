import time
import json
from redis_db import get_redis

def processar_pedidos():
    r = get_redis()
    nome_fila = "fila_pedidos"
    
    print(f"[*] Worker iniciado. Aguardando pedidos na fila '{nome_fila}'...")
    
    while True:
        # BRPOP remove o último elemento da lista ou bloqueia até que um esteja disponível
        # Retorna uma tupla (chave, valor)
        resultado = r.brpop(nome_fila, timeout=0)
        
        if resultado:
            _, mensagem = resultado
            dados = json.loads(mensagem)
            
            print(f"[+] Processando pedido ID {dados.get('id')} para {dados.get('item')}...")
            
            # Simula um processamento demorado
            time.sleep(2)
            
            print(f"[OK] Pedido {dados.get('id')} processado com sucesso!")

if __name__ == "__main__":
    processar_pedidos()
