from pydantic import BaseModel
from typing import Optional

# Entrada: criação de uma tarefa
class TarefaCreate(BaseModel):
    titulo: str
    descricao: Optional[str] = None

# Entrada: atualização de uma tarefa (campos opcionais)
class TarefaUpdate(BaseModel):
    titulo: Optional[str] = None
    descricao: Optional[str] = None
    concluida: Optional[bool] = None

# Saída: Tarefa lida do banco
class TarefaResponse(BaseModel):
    id: int
    titulo: str
    descricao: Optional[str]
    concluida: bool

    class Config:
        from_attributes = True # lê do ORM